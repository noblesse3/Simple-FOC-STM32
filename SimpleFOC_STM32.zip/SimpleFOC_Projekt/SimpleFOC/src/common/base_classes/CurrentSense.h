#ifndef CURRENTSENSE_H
#define CURRENTSENSE_H

#include "FOCDriver.h"
#include "BLDCDriver.h"
#include "../foc_utils.h"
#include "../time_utils.h"
#include <cstdio>

/**
 *  Current sensing abstract class definition
 * Each current sensing implementation needs to extend this interface
 */
class CurrentSense {
public:
    /**
     *  Function initializing the CurrentSense class
     *   - All the necessary initializations of ADC and sync should be implemented here
     *
     * @returns -  0 - for failure &  1 - for success 
     */
    virtual int init() = 0;

    /**
     * Linking the current sense with the motor driver
     * Only necessary if synchronization between the two is required
     */
    void linkDriver(FOCDriver* driver);

    // variables
    bool skip_align = false; //!< Variable signaling that the phase current direction should be verified during initFOC()

    FOCDriver* driver = nullptr; //!< Driver link
    bool initialized = false; //!< True if current sense was successfully initialized
    void* params = nullptr; //!< Pointer to hardware-specific parameters of current sensing
    DriverType driver_type = DriverType::Unknown; //!< Driver type (BLDC or Stepper)

    // ADC measurement gain for each phase
    float gain_a; //!< Phase A gain
    float gain_b; //!< Phase B gain
    float gain_c; //!< Phase C gain

    float offset_ia; //!< Zero current A voltage value (center of the ADC reading)
    float offset_ib; //!< Zero current B voltage value (center of the ADC reading)
    float offset_ic; //!< Zero current C voltage value (center of the ADC reading)

    // Hardware variables
    int pinA; //!< Pin A analog pin for current measurement
    int pinB; //!< Pin B analog pin for current measurement
    int pinC; //!< Pin C analog pin for current measurement

    /**
     * Function intended to verify if:
     *   - Phase currents are oriented properly
     *   - If their order is the same as driver phases
     * 
     * This function corrects the alignment errors if possible, and if no such thing is needed, it can be left empty (return 1)
     * @returns -  
     *     0 - failure
     *     1 - success and nothing changed
     *     2 - success but pins reconfigured
     *     3 - success but gains inverted
     *     4 - success but pins reconfigured and gains inverted
     */
    virtual int driverAlign(float align_voltage, bool modulation_centered = false);

    /**
     * Function reading the phase currents a, b, and c
     * - This function will be used with the FOC control through the function
     *   CurrentSense::getFOCCurrents(electrical_angle)
     * - It returns current c equal to 0 if only two phase measurements are available
     * 
     * @return PhaseCurrent_s current values
     */
    virtual PhaseCurrent_s getPhaseCurrents() = 0;

    /**
     * Function reading the magnitude of the current set to the motor
     * - It returns the absolute or signed magnitude if possible
     * - It can receive the motor electrical angle to help with calculation
     *
     * @param angle_el - electrical angle of the motor (optional) 
     */
    virtual float getDCCurrent(float angle_el = 0);

    /**
     * Function used for FOC control, it reads the DQ currents of the motor 
     * - It uses the function getPhaseCurrents internally
     * 
     * @param angle_el - motor electrical angle
     */
    DQCurrent_s getFOCCurrents(float angle_el);

    /**
     * Function used for Clarke transform in FOC control
     * - It reads the phase currents of the motor
     * - It returns the alpha and beta currents
     * 
     * @param current - phase current
     */
    ABCurrent_s getABCurrents(PhaseCurrent_s current);

    /**
     * Function used for Park transform in FOC control
     * - It reads the Alpha Beta currents and electrical angle of the motor
     * - It returns the D and Q currents
     * 
     * @param current - phase current
     */
    DQCurrent_s getDQCurrents(ABCurrent_s current, float angle_el);

    /**
     * Enable the current sense. Default implementation does nothing, but you can
     * override it to do something useful.
     */
    virtual void enable();

    /**
     * Disable the current sense. Default implementation does nothing, but you can
     * override it to do something useful.
     */
    virtual void disable();

    /**
     * Function used to align the current sense with the BLDC motor driver
     */
    int alignBLDCDriver(float align_voltage, BLDCDriver* driver, bool modulation_centered);

    /**
     * Function used to align the current sense with the Stepper motor driver
     */


    /**
     * Function used to read the average current values over N samples
     */
    PhaseCurrent_s readAverageCurrents(int N = 100);
};

#endif
