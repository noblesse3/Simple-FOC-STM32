#ifndef COMMANDS_H
#define COMMANDS_H

#include "stm32g4xx_hal.h"
#include <cstring>
#include <cstdio>
#include "../common/base_classes/FOCMotor.h"
#include "../common/pid.h"
#include "../common/lowpass_filter.h"

#define MAX_COMMAND_LENGTH 20

// Commander verbose display to the user type
enum VerboseMode : uint8_t {
  nothing       = 0x00, // display nothing - good for monitoring
  on_request    = 0x01, // display only on user request
  user_friendly = 0x02,  // display textual messages to the user
  machine_readable = 0x03 // display machine readable commands, matching commands to set each settings
};

// callback function pointer definition
typedef void (* CommandCallback)(char*); //!< command callback function pointer

/**
 * Commander class implementing string communication protocol based on IDvalue (ex AB5.321 - command id `A`, sub-command id `B`, value `5.321`)
 */
class Commander {
public:
    Commander(UART_HandleTypeDef* huart, char eol = '\n', bool echo = false);

    void run();
    void run(char* user_input);

    void add(char id, CommandCallback onCommand, const char* label = nullptr);

    VerboseMode verbose = VerboseMode::user_friendly; //!< flag signaling that the commands should output user understandable text
    uint8_t decimal_places = 3; //!< number of decimal places to be used when displaying numbers

    void motor(FOCMotor* motor, char* user_cmd);
    void lpf(LowPassFilter* lpf, char* user_cmd);
    void pid(PIDController* pid, char* user_cmd);
    void scalar(float* value, char* user_cmd);
    void target(FOCMotor* motor, char* user_cmd, const char* separator = " ");
    void motion(FOCMotor* motor, char* user_cmd, const char* separator = " ");

    bool isSentinel(char ch);

private:
    CommandCallback call_list[20]; //!< array of command callback pointers
    char call_ids[20]; //!< added callback commands
    const char* call_label[20]; //!< added callback labels
    int call_count = 0; //!< number callbacks that are subscribed

    char received_chars[MAX_COMMAND_LENGTH] = {0}; //!< so far received user message - waiting for newline
    int rec_cnt = 0; //!< number of characters received

    UART_HandleTypeDef* huart = nullptr; //!< UART handle for communication
    char eol = '\n'; //!< end of line sentinel character
    bool echo = false; //!< echo last typed character (for command line feedback)

    void printVerbose(const char* message);
    void print(const float number);
    void print(const int number);
    void print(const char* message);
    void println(const float number);
    void println(const int number);
    void println(const char* message);
    void printError();
};

Commander::Commander(UART_HandleTypeDef* huart, char eol, bool echo) {
    this->huart = huart;
    this->eol = eol;
    this->echo = echo;
}

void Commander::run() {
    if (huart == nullptr) return;

    uint8_t received;
    if (HAL_UART_Receive(huart, &received, 1, HAL_MAX_DELAY) == HAL_OK) {
        if (echo) {
            HAL_UART_Transmit(huart, &received, 1, HAL_MAX_DELAY);
        }
        if (received != eol && rec_cnt < MAX_COMMAND_LENGTH - 1) {
            received_chars[rec_cnt++] = received;
        } else {
            received_chars[rec_cnt] = '\0';
            run(received_chars);
            rec_cnt = 0;
        }
    }
}

void Commander::run(char* user_input) {
    for (int i = 0; i < call_count; i++) {
        if (user_input[0] == call_ids[i]) {
            call_list[i](user_input + 1);
            return;
        }
    }
    printError();
}

void Commander::add(char id, CommandCallback onCommand, const char* label) {
    if (call_count < 20) {
        call_ids[call_count] = id;
        call_list[call_count] = onCommand;
        call_label[call_count] = label;
        call_count++;
    }
}

void Commander::printVerbose(const char* message) {
    if (verbose == VerboseMode::user_friendly && huart) {
        HAL_UART_Transmit(huart, (uint8_t*)message, strlen(message), HAL_MAX_DELAY);
    }
}

void Commander::print(const float number) {
    if (huart) {
        char buffer[32];
        snprintf(buffer, sizeof(buffer), "%.3f", number); // @suppress("Float formatting support")
        HAL_UART_Transmit(huart, (uint8_t*)buffer, strlen(buffer), HAL_MAX_DELAY);
    }
}

void Commander::print(const int number) {
    if (huart) {
        char buffer[32];
        snprintf(buffer, sizeof(buffer), "%d", number);
        HAL_UART_Transmit(huart, (uint8_t*)buffer, strlen(buffer), HAL_MAX_DELAY);
    }
}

void Commander::print(const char* message) {
    if (huart) {
        HAL_UART_Transmit(huart, (uint8_t*)message, strlen(message), HAL_MAX_DELAY);
    }
}

void Commander::println(const float number) {
    print(number);
    print("\r\n");
}

void Commander::println(const int number) {
    print(number);
    print("\r\n");
}

void Commander::println(const char* message) {
    print(message);
    print("\r\n");
}

void Commander::printError() {
    println("Error: Unknown command");
}

#endif
