#ifndef __SIMPLEFOCDEBUG_H__
#define __SIMPLEFOCDEBUG_H__

#include "stm32g4xx_hal.h"
#include <cstring>
#include <cstdio>

/**
 * SimpleFOCDebug class
 * 
 * This class is used to print debug messages to a chosen output.
 * Currently, STM32 HAL UART is supported as the output.
 * 
 * Activate debug output globally by calling enable(), optionally passing
 * in a UART_HandleTypeDef instance. If none is provided, debugging is disabled.
 * 
 * To produce debug output, use the macro SIMPLEFOC_DEBUG:
 *   SIMPLEFOC_DEBUG("Debug message!");
 *   SIMPLEFOC_DEBUG("a float value:", 123.456f);
 *   SIMPLEFOC_DEBUG("an integer value: ", 123);
 * 
 * Keep debugging output short and simple. STM32 MCUs have limited
 * RAM and serial output capabilities.
 * 
 * You can also disable debug output completely. In this case all debug output 
 * and the SimpleFOCDebug class is removed from the compiled code.
 * Add -DSIMPLEFOC_DISABLE_DEBUG to your compiler flags to disable debug in
 * this way.
 * 
 **/

// #define SIMPLEFOC_DISABLE_DEBUG

#ifndef SIMPLEFOC_DISABLE_DEBUG 

class SimpleFOCDebug {
public:
    static void enable(UART_HandleTypeDef* huart) {
        _debugUart = huart;
    }

    static void println(const char* msg) {
        if (_debugUart) {
            HAL_UART_Transmit(_debugUart, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
            HAL_UART_Transmit(_debugUart, (uint8_t*)"\r\n", 2, HAL_MAX_DELAY);
        }
    }

    static void println(const char* msg, float val) {
        if (_debugUart) {
            char buffer[64];
            snprintf(buffer, sizeof(buffer), "%s %.2f\r\n", msg, val); // @suppress("Float formatting support")
            HAL_UART_Transmit(_debugUart, (uint8_t*)buffer, strlen(buffer), HAL_MAX_DELAY);
        }
    }

    static void println(const char* msg, int val) {
        if (_debugUart) {
            char buffer[64];
            snprintf(buffer, sizeof(buffer), "%s %d\r\n", msg, val);
            HAL_UART_Transmit(_debugUart, (uint8_t*)buffer, strlen(buffer), HAL_MAX_DELAY);
        }
    }

    static void println(const char* msg, char val) {
        if (_debugUart) {
            char buffer[64];
            snprintf(buffer, sizeof(buffer), "%s %c\r\n", msg, val);
            HAL_UART_Transmit(_debugUart, (uint8_t*)buffer, strlen(buffer), HAL_MAX_DELAY);
        }
    }

    static void println() {
        if (_debugUart) {
            HAL_UART_Transmit(_debugUart, (uint8_t*)"\r\n", 2, HAL_MAX_DELAY);
        }
    }

    static void println(int val) {
        if (_debugUart) {
            char buffer[32];
            snprintf(buffer, sizeof(buffer), "%d\r\n", val);
            HAL_UART_Transmit(_debugUart, (uint8_t*)buffer, strlen(buffer), HAL_MAX_DELAY);
        }
    }

    static void println(float val) {
        if (_debugUart) {
            char buffer[32];
            snprintf(buffer, sizeof(buffer), "%.2f\r\n", val); // @suppress("Float formatting support")
            HAL_UART_Transmit(_debugUart, (uint8_t*)buffer, strlen(buffer), HAL_MAX_DELAY);
        }
    }

protected:
    static UART_HandleTypeDef* _debugUart;
};

UART_HandleTypeDef* SimpleFOCDebug::_debugUart = nullptr;

#define SIMPLEFOC_DEBUG(msg, ...) \
    SimpleFOCDebug::println(msg, ##__VA_ARGS__)

#else //ifndef SIMPLEFOC_DISABLE_DEBUG

#define SIMPLEFOC_DEBUG(msg, ...)

#endif //ifndef SIMPLEFOC_DISABLE_DEBUG
#endif
