#include "stm32g4xx_hal.h"
#include <string.h>
#include "C:\STM_WORKSPACE\SimpleFOC_Projekt\SimpleFOC\src\BLDCMotor.h"
#include "C:\STM_WORKSPACE\SimpleFOC_Projekt\SimpleFOC\src\drivers\BLDCDriver3PWM.h"

TIM_HandleTypeDef htim1; // Timer pour PWM
UART_HandleTypeDef huart1; // UART pour debug

BLDCMotor motor(7); // 7 paires de pôles
BLDCDriver3PWM driver(PA8, PA9, PA10, PB0); // Pilote PWM

void SystemClock_Config(void);
void MX_GPIO_Init(void);
void MX_TIM1_Init(void);
void MX_USART1_UART_Init(void);
void Error_Handler(void);

int main(void) {
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_TIM1_Init();
    MX_USART1_UART_Init();

    driver.voltage_power_supply = 12;
    if (!driver.init()) {
        Error_Handler();
    }
    HAL_UART_Transmit(&huart1, (uint8_t *)"Driver initialized\n", 19, HAL_MAX_DELAY);

    motor.linkDriver(&driver);
    motor.controller = MotionControlType::torque;
    motor.torque_controller = TorqueControlType::voltage;
    motor.voltage_limit = 6;
    if (!motor.initFOC()) {
        Error_Handler();
    }
    HAL_UART_Transmit(&huart1, (uint8_t *)"FOC initialized\n", 17, HAL_MAX_DELAY);

    while (1) {
        motor.loopFOC();
        motor.move(2); // Commande du moteur
        HAL_Delay(10); // Pause de 10 ms
    }
}

void Error_Handler(void) {
    __disable_irq();
    const char *errorMsg = "Critical Error!\n";
    HAL_UART_Transmit(&huart1, (uint8_t *)errorMsg, strlen(errorMsg), HAL_MAX_DELAY);

    while (1) {
        HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
        HAL_Delay(500);
    }
}
