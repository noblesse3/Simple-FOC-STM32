#include "BLDCMotor.h"

// Constructor for the motor, initializing pole pairs and default values
BLDCMotor::BLDCMotor(int pp) {
    pole_pairs = pp;
    voltage_power_supply = 12.0;  // Default power supply voltage (e.g., 12V)
    controller = MotionControlType::velocity;  // Default control mode is velocity
}

// Link the driver to the motor
void BLDCMotor::linkDriver(BLDCDriver3PWM* driver) {
    this->driver = driver;
}

// Link the sensor to the motor
void BLDCMotor::linkSensor(HallSensor* sensor) {
    this->sensor = sensor;
}

// Initialize the motor, including driver and sensor
void BLDCMotor::init() {
    if (driver) {
        driver->init();  // Initialize the PWM driver
    }
    if (sensor) {
        sensor->init();  // Initialize the sensor
    }
    // Debug print (can be replaced with UART)
    printf("Motor initialized\n");
}

// FOC control loop (calculate and apply current to achieve desired state)
void BLDCMotor::loopFOC() {
    if (sensor) {
        // Retrieve current angle and velocity from the sensor
        current_angle = sensor->getAngle();
        current_velocity = sensor->getVelocity();
    }
    // Example: Apply a simple voltage (testing purposes)
    if (driver) {
        driver->setPwm(voltage_power_supply, 0.0, 0.0);  // Power phase U
    }
}

// Execute the desired motion control (based on torque, velocity, or angle)
void BLDCMotor::move(float target) {
    if (controller == MotionControlType::velocity) {
        // Calculate the control signal using the velocity PID controller
        float command = PID_velocity.compute(target, current_velocity);
        // Apply the calculated PWM signals to the driver
        if (driver) {
            driver->setPwm(command, -command, 0.0);  // Example control for two phases
        }
    }
}
