#include "HallSensor.h"

// Constructor: Initialize the Hall sensor with GPIO pins and CPR
HallSensor::HallSensor(GPIO_TypeDef* GPIOA_port, uint16_t GPIOA_pin,
                       GPIO_TypeDef* GPIOB_port, uint16_t GPIOB_pin,
                       GPIO_TypeDef* GPIOC_port, uint16_t GPIOC_pin, int cpr) {
    this->GPIOA_port = GPIOA_port;
    this->GPIOA_pin = GPIOA_pin;
    this->GPIOB_port = GPIOB_port;
    this->GPIOB_pin = GPIOB_pin;
    this->GPIOC_port = GPIOC_port;
    this->GPIOC_pin = GPIOC_pin;
    this->cpr = cpr;

    this->previous_state = 0;
    this->last_update_time = 0;
    this->velocity = 0.0f;
}

// Initialize the Hall sensor (configure GPIO pins)
void HallSensor::init() {
    // Pins are configured via CubeMX; no further setup needed here.
    // Debug output (optional)
    printf("Hall sensor initialized\n");
}

// Get the rotor angle based on Hall sensor states
float HallSensor::getAngle() {
    // Read the states of the Hall sensors
    int stateA = HAL_GPIO_ReadPin(GPIOA_port, GPIOA_pin);
    int stateB = HAL_GPIO_ReadPin(GPIOB_port, GPIOB_pin);
    int stateC = HAL_GPIO_ReadPin(GPIOC_port, GPIOC_pin);

    // Combine the states into a single integer (binary combination)
    int hall_state = (stateA << 2) | (stateB << 1) | stateC;

    // Map the Hall state to an angle (electrical)
    float angle = (hall_state * 2.0f * M_PI) / 6.0f;  // 6 states in a BLDC motor

    return angle;  // Return the angle in radians
}

// Get the rotor velocity (rad/s)
float HallSensor::getVelocity() {
    // Read the current time
    uint32_t now = millis();  // Get current time in ms (using STM32 HAL_GetTick())

    // Calculate velocity based on the time difference between updates
    if (last_update_time != 0) {
        uint32_t delta_time = now - last_update_time;  // Time since last update (ms)

        if (delta_time > 0) {
            // Velocity = (change in angle) / (time interval)
            velocity = (2.0f * M_PI) / (delta_time / 1000.0f);  // rad/s
        }
    }

    // Update the last update time
    last_update_time = now;

    return velocity;
}
