#ifndef HallSensor_h
#define HallSensor_h

#include "stm32g4xx_hal.h"  // Adapter selon ta série STM32 (par ex. G4)
#include "common/time_utils.h"  // Pour gérer les calculs liés au temps

class HallSensor {
public:
    // Constructor to initialize the HallSensor with its GPIO pins and CPR (Counts Per Revolution)
    HallSensor(GPIO_TypeDef* GPIOA_port, uint16_t GPIOA_pin,
               GPIO_TypeDef* GPIOB_port, uint16_t GPIOB_pin,
               GPIO_TypeDef* GPIOC_port, uint16_t GPIOC_pin, int cpr);

    // Initialize the Hall sensor
    void init();

    // Retrieve the rotor angle (in electrical degrees or radians)
    float getAngle();

    // Retrieve the rotor velocity (rad/s)
    float getVelocity();

private:
    // Pins configuration
    GPIO_TypeDef* GPIOA_port;
    uint16_t GPIOA_pin;

    GPIO_TypeDef* GPIOB_port;
    uint16_t GPIOB_pin;

    GPIO_TypeDef* GPIOC_port;
    uint16_t GPIOC_pin;

    int cpr;  // Counts Per Revolution (physical resolution of the Hall sensors)

    // Variables to store the previous state and timestamps for velocity calculation
    int previous_state;
    uint32_t last_update_time;
    float velocity;
};

#endif
