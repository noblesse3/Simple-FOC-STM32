#ifndef BLDCMotor_h
#define BLDCMotor_h

#include "drivers/BLDCDriver3PWM.h"      // Driver for 3-phase PWM control
#include "sensors/HallSensor.h"          // Hall sensor for position feedback
#include "common/foc_utils.h"            // Utilities for FOC (Clark/Park transforms)
#include "common/time_utils.h"          // PID controller for velocity and position control
#include "current_sense/GenericCurrentSense.h"  // Optional current sensing
#include "stm32g4xx_hal.h"               // HAL library for STM32 (adjust based on MCU)

enum MotionControlType {
    torque,    // Control torque directly
    velocity,  // Control speed
    angle      // Control position
};

class BLDCMotor {
public:
    // Constructor to initialize the motor with the number of pole pairs
    BLDCMotor(int pole_pairs);

    // Link driver to the motor
    void linkDriver(BLDCDriver3PWM* driver);

    // Link sensor to the motor (e.g., Hall sensor)
    void linkSensor(HallSensor* sensor);

    // Initialize the motor
    void init();

    // Run FOC control loop (called periodically in the main loop)
    void loopFOC();

    // Set motion command (velocity, torque, or angle based on control type)
    void move(float target);

    // Public configuration parameters
    MotionControlType controller;    // Type of control: torque, velocity, or angle
    float voltage_power_supply;      // Voltage applied to the motor (e.g., 12V)
    PIDController PID_velocity;      // PID controller for velocity
    PIDController PID_angle;         // PID controller for angle

private:
    int pole_pairs;                  // Number of pole pairs in the motor
    BLDCDriver3PWM* driver;          // Pointer to the motor driver
    HallSensor* sensor;              // Pointer to the sensor for position feedback
    float current_velocity;          // Current velocity estimate
    float current_angle;             // Current angle estimate
};

#endif
